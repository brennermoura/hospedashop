import { useState } from 'react';
import ScrollReveal from './ScrollReveal';

const faqs = [
  {
    question: 'Quanto tempo leva para meu site ficar pronto?',
    answer:
      'Na maioria dos casos, sites institucionais ficam prontos em até 10 dias úteis após recebermos todas as informações necessárias. Projetos maiores, como lojas virtuais, sistemas e apps, têm prazo definido depois do entendimento do escopo, porque envolvem mais telas, integrações, regras de negócio e validações.',
  },
  {
    question: 'O que está incluso no site a partir de R$449,90?',
    answer:
      'O plano inicial inclui a criação de um site profissional, estrutura responsiva para celular, tablet e computador, configuração básica, publicação online e orientação para deixar tudo funcionando corretamente. Dependendo da necessidade da empresa, também podemos incluir páginas extras, integrações, e-mails profissionais, manutenção e melhorias recorrentes.',
  },
  {
    question: 'Esse valor de R$449,90 é fixo para qualquer site?',
    answer:
      'Não. O valor de R$449,90 é o investimento inicial para projetos mais simples. O preço final depende do que sua empresa precisa: quantidade de páginas, conteúdo, funcionalidades, integrações, formulários, área administrativa, loja virtual ou recursos personalizados. A ideia é cobrar pelo que realmente faz sentido, não empurrar um pacote aleatório com nome bonito.',
  },
  {
    question: 'Preciso pagar alguma mensalidade?',
    answer:
      'Depende do tipo de projeto e dos serviços contratados. Alguns projetos podem ter apenas o valor de desenvolvimento, enquanto outros podem incluir mensalidade para hospedagem, suporte, manutenção, atualizações, e-mail profissional ou evolução contínua. Tudo isso é explicado antes da contratação, sem surpresa escondida no rodapé igual contrato de operadora.',
  },
  {
    question: 'Preciso comprar o domínio separado?',
    answer:
      'Sim. O domínio, como www.suaempresa.com.br, é contratado separadamente e fica registrado no nome da sua empresa. Mas você não precisa se preocupar com a parte técnica: orientamos a compra e fazemos toda a configuração para deixar o site e os e-mails funcionando corretamente.',
  },
  {
    question: 'Vocês também criam lojas virtuais, sistemas e apps?',
    answer:
      'Sim. Além de sites institucionais, desenvolvemos lojas virtuais, sistemas web e apps híbridos para empresas que precisam ir além da presença online. Cada projeto é orçado conforme a necessidade, para garantir que a solução faça sentido para a operação e não seja só um monte de tela bonita sem função.',
  },
  {
    question: 'Como funciona o e-mail profissional?',
    answer:
      'Configuramos e-mails com o domínio da sua empresa, como contato@suaempresa.com.br. Isso passa mais confiança para o cliente, melhora a imagem da marca e evita aquele visual improvisado de negócio sério usando e-mail pessoal para vender. Convenhamos, ajuda bastante.',
  },
  {
    question: 'Onde os projetos ficam hospedados?',
    answer:
      'Os projetos podem ser publicados em hospedagem na nuvem, em um ambiente preparado para manter seu site, loja, sistema ou app disponível para seus clientes. Também orientamos a melhor opção conforme o tipo de projeto, volume de acesso e necessidade da empresa.',
  },
  {
    question: 'O site vai aparecer no Google?',
    answer:
      'Sim. Desenvolvemos o site com estrutura preparada para ser encontrado e lido pelo Google, usando boas práticas de performance, organização de conteúdo e SEO básico. Para acelerar resultados e atrair clientes mais rápido, também podemos orientar estratégias com tráfego pago.',
  },
  {
    question: 'O site funciona em celular e tablet?',
    answer:
      'Sim. Todos os projetos são pensados para funcionar bem em celular, tablet e computador. Isso é essencial, porque hoje boa parte dos clientes acessa pelo celular antes mesmo de abrir um notebook. Se a experiência mobile for ruim, o cliente fecha a página e vai embora sem cerimônia.',
  },
  {
    question: 'Eu preciso saber mexer em site ou tecnologia?',
    answer:
      'Não. A HospedaShop cuida da parte técnica e orienta você no que for necessário. Nosso objetivo é transformar sua necessidade em uma solução clara, funcional e fácil de entender. Você não precisa decorar nome de servidor, DNS, SSL ou qualquer outro palavrão técnico para ter seu projeto online.',
  },
  {
    question: 'Como faço para começar?',
    answer:
      'O primeiro passo é chamar nossa equipe e explicar o que sua empresa precisa. A partir disso, entendemos o objetivo do projeto, indicamos o melhor caminho, alinhamos prazo, investimento e próximos passos. Assim você começa com clareza, sem chute, sem enrolação e sem orçamento tirado da cartola.',
  },
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggle = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="relative py-24 sm:py-32 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#050b18] to-[#070e1f]" />
      <div className="orb w-80 h-80 bg-cyan-600/8 top-1/2 -translate-y-1/2 right-0" />

      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <ScrollReveal>
          <div className="text-center mb-14">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-cyan-500/10 border border-cyan-500/20 mb-6">
              <span className="text-cyan-400 text-xs font-semibold tracking-widest uppercase">
                Dúvidas frequentes
              </span>
            </div>

            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white mb-4 tracking-tight">
              Perguntas{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400">
                Frequentes
              </span>
            </h2>

            <p className="text-slate-400 text-base sm:text-lg">
              Respostas diretas para você entender como funciona antes de começar
            </p>
          </div>
        </ScrollReveal>

        {/* FAQ List */}
        <div className="space-y-3">
          {faqs.map((faq, index) => (
            <ScrollReveal key={index} delay={index * 60}>
              <div
                className={`rounded-2xl border transition-all duration-300 overflow-hidden ${
                  openIndex === index
                    ? 'bg-blue-950/30 border-blue-500/30'
                    : 'bg-white/[0.02] border-white/5 hover:border-white/10 hover:bg-white/[0.04]'
                }`}
              >
                <button
                  onClick={() => toggle(index)}
                  className="w-full flex items-center justify-between p-5 sm:p-6 text-left group"
                >
                  <span
                    className={`text-sm sm:text-base font-semibold transition-colors duration-200 pr-4 ${
                      openIndex === index
                        ? 'text-white'
                        : 'text-slate-300 group-hover:text-white'
                    }`}
                  >
                    {faq.question}
                  </span>

                  <div
                    className={`flex-shrink-0 w-8 h-8 rounded-xl flex items-center justify-center transition-all duration-300 ${
                      openIndex === index
                        ? 'bg-blue-500 rotate-45'
                        : 'bg-white/5 group-hover:bg-white/10'
                    }`}
                  >
                    <svg
                      width="14"
                      height="14"
                      viewBox="0 0 24 24"
                      fill="none"
                      className={`transition-colors duration-200 ${
                        openIndex === index ? 'text-white' : 'text-slate-400'
                      }`}
                      stroke="currentColor"
                      strokeWidth={2.5}
                      strokeLinecap="round"
                    >
                      <line x1="12" y1="5" x2="12" y2="19" />
                      <line x1="5" y1="12" x2="19" y2="12" />
                    </svg>
                  </div>
                </button>

                <div
                  className={`overflow-hidden transition-all duration-300 ${
                    openIndex === index ? 'max-h-64' : 'max-h-0'
                  }`}
                >
                  <div className="px-5 sm:px-6 pb-5 sm:pb-6">
                    <div className="h-px bg-gradient-to-r from-blue-500/30 to-transparent mb-4" />

                    <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
                      {faq.answer}
                    </p>
                  </div>
                </div>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
}